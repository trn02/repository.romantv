from __future__ import unicode_literals

import time

import xbmc
import xbmcaddon


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
REFRESH_INTERVAL_SECONDS = 6 * 60 * 60
STARTUP_DELAY_SECONDS = 30


def log(message):
    xbmc.log("[{}] {}".format(ADDON_ID, message), xbmc.LOGINFO)


def main():
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(STARTUP_DELAY_SECONDS):
        return

    log("service startup repo refresh")
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.executebuiltin("UpdateLocalAddons")

    while not monitor.waitForAbort(REFRESH_INTERVAL_SECONDS):
        log("service periodic repo refresh")
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmc.executebuiltin("UpdateLocalAddons")


if __name__ == "__main__":
    main()
